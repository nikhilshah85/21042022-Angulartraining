import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavigationComponent } from './navigation/navigation.component';
import { NotfoundComponent } from './components/notfound/notfound.component';
import { SalesComponent } from './team/teamcomponent/sales/sales.component';
import { MarketingComponent } from './team/teamcomponent/marketing/marketing.component';
import { TechnicalComponent } from './team/teamcomponent/technical/technical.component';
import { AccountsComponent } from './team/teamcomponent/accounts/accounts.component';
import { TeamComponent } from './team/team.component';

@NgModule({
  declarations: [
    AppComponent,  
    NavigationComponent,TeamComponent, NotfoundComponent, SalesComponent, MarketingComponent, TechnicalComponent, AccountsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
