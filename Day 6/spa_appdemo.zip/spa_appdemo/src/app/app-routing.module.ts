import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { NotfoundComponent } from './components/notfound/notfound.component';
import { ContactComponent } from './contact/contact.component';
import { CultureComponent } from './culture/culture.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NewsComponent } from './news/news.component';
import { RegisterComponent } from './register/register.component';
import { TeamComponent } from './team/team.component';
import { AccountsComponent } from './team/teamcomponent/accounts/accounts.component';
import { MarketingComponent } from './team/teamcomponent/marketing/marketing.component';
import { SalesComponent } from './team/teamcomponent/sales/sales.component';
import { TechnicalComponent } from './team/teamcomponent/technical/technical.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutComponent},
  {path:'contact',component:ContactComponent},
  {path:'culture',component:CultureComponent},
  {path:'news',component:NewsComponent},
  {path:'teams',component:TeamComponent,children:[
      {path:'sales',component:SalesComponent},
      {path:'accounts',component:AccountsComponent},
      {path:'marketing',component:MarketingComponent},
      {path:'technical',component:TechnicalComponent},
  ]},
  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'**',component:NotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
