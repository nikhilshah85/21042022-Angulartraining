import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ProductlisComponent } from './components/productlis/productlis.component';
import { SearchproductComponent } from './components/searchproduct/searchproduct.component';
import { AddproductComponent } from './components/addproduct/addproduct.component';
import {HttpClientModule} from '@angular/common/http';
import { CommentsComponent } from './components/comments/comments.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductlisComponent,
    SearchproductComponent,
    AddproductComponent,
    CommentsComponent
  ],
  imports: [
    BrowserModule, HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
