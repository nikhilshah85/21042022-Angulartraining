import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GetrestdataService {

  _http:HttpClient;
  mycommetsData:any;

  constructor(_httpREf:HttpClient)
  {
      this._http = _httpREf;
  }

  getCommentsData()
  {
    return this._http.get('https://jsonplaceholder.typicode.com/comments').subscribe( (data)=>{
      this.mycommetsData = data;
      console.log(this.mycommetsData);
    })
  }


}
