import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {


 myName = "Nikhil Shah";

 productList = [
   {pId:101, pName:'Pepsi',pCategory:'Cold-Drink',pPrice:50},
   {pId:102, pName:'Fossil',pCategory:'Watch',pPrice:50},
   {pId:103, pName:'Frooti',pCategory:'Cold-Drink',pPrice:50},
   {pId:104, pName:'Iphone',pCategory:'Phone',pPrice:50},
   {pId:105, pName:'Dell',pCategory:'Electronics',pPrice:50},
 ]

 changeMyName()
 {
   this.myName = "Alex Furgueson";
 }



  constructor() { }
}
