import { TestBed } from '@angular/core/testing';

import { GetrestdataService } from './getrestdata.service';

describe('GetrestdataService', () => {
  let service: GetrestdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetrestdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
