import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-searchproduct',
  templateUrl: './searchproduct.component.html',
  styleUrls: ['./searchproduct.component.css']
})
export class SearchproductComponent implements OnInit {

  _productser:ProductsService;


  constructor(private _productSerREf:ProductsService)
  {
    this._productser = _productSerREf;
   }

  ngOnInit(): void {
  }

}
