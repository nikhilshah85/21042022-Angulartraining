import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  _productser:ProductsService;
  constructor(private _productSerRef:ProductsService) 
  {
    this._productser = _productSerRef;
   }

  ngOnInit(): void {
  }

}
