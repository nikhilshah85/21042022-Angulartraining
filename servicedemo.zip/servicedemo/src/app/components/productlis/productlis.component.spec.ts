import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductlisComponent } from './productlis.component';

describe('ProductlisComponent', () => {
  let component: ProductlisComponent;
  let fixture: ComponentFixture<ProductlisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductlisComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductlisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
