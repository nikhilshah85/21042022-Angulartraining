import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-productlis',
  templateUrl: './productlis.component.html',
  styleUrls: ['./productlis.component.css']
})
export class ProductlisComponent implements OnInit {
  
  _productser:ProductsService;
  // _pserveice:ProductsService obj = new ProductsService();
                                //object of this class will be created by angular framework, and it will injected here
  constructor(private _prodSerRef:ProductsService) 
  {
    this._productser = _prodSerRef;
  }

 
  ngOnInit(): void {
  }

}
