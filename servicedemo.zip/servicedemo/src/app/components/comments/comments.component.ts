import { Component, OnInit } from '@angular/core';
import { GetrestdataService } from 'src/app/services/getrestdata.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  _getRestData:GetrestdataService;
  
  constructor(_getRestDataRef:GetrestdataService) {
    this._getRestData = _getRestDataRef;
   }

  ngOnInit(): void {
  }

}
