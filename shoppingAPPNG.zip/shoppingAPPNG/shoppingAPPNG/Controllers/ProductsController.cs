﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using shoppingAPPNG.Model;
namespace shoppingAPPNG.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        shoppingAPPDBContext _db = new shoppingAPPDBContext(); //they use Dependency injection here


        [HttpGet]
        [Route("plist")]
        public IActionResult GetAppProducts()
        {
           return Ok(_db.Products.ToList());
        }

        [HttpGet]
        [Route("plist/{id}")]
        public IActionResult GetProductByid(int id)
        {
            var product = _db.Products.Find(id);
            if (product == null)
            {
                return NotFound("Product with ID " + id + " is not found in system");
            }
            else
            {
                return Ok(product);
            }
        }

        [HttpGet]
        [Route("plist/available")]
        public IActionResult GetAvailableProducts()
        {
            var products = (from p in _db.Products
                            where p.PIsInStock == true
                            select p).ToList();
            return Ok(products);
        }

        [HttpGet]
        [Route("plist/notavailable")]
        public IActionResult GetNonAvailableProducts()
        {
            var products = (from p in _db.Products
                            where p.PIsInStock == false
                            select p).ToList();
            return Ok(products);
        }

        [HttpPost]
        [Route("plist/add")]
        public IActionResult AddProduct(Product newProduct)
        {
            _db.Products.Add(newProduct);
            _db.SaveChanges();
            return Created("", "Product Added Successfully");
        }

        [HttpDelete]
        [Route("plist/delete/{id}")]
        public IActionResult DeleteProduct(int id)
        {
            var product = (from p in _db.Products
                           where p.PId == id
                           select p).Single();
            if(product == null)
            {
                return BadRequest("Cannot Delete a product which is not in system");
            }
            return Accepted("Product Deleted Successfully");
        }


        [HttpPut]
        [Route("plist/edit")]
        public IActionResult Updateproduct(Product updates)
        {
          var pr = (from p in _db.Products
                  where p.PId == updates.PId
                  select p).Single();

            pr.PName = updates.PName;
            pr.PManufacturer = updates.PManufacturer;
            pr.PPrice = updates.PPrice;
            pr.PCategory = updates.PCategory;
            pr.PIsInStock = updates.PIsInStock;
            _db.SaveChanges();
            return Accepted("", "Product Updated Successfullt");

        }
    }
}
