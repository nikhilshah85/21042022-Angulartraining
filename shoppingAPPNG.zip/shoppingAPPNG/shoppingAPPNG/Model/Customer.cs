﻿using System;
using System.Collections.Generic;

namespace shoppingAPPNG.Model
{
    public partial class Customer
    {
        public int CId { get; set; }
        public string? CName { get; set; }
        public string? CCategory { get; set; }
        public int? CWalletBalane { get; set; }
        public bool? CIsActive { get; set; }
    }
}
