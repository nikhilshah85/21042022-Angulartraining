import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private _http: HttpClient;

  constructor(private _httpSerRef: HttpClient)
  {
    this._http = _httpSerRef;
  }

  getProducts() {
    this._http.get('https://localhost:7222/api/products/plist').subscribe();
  }

}
