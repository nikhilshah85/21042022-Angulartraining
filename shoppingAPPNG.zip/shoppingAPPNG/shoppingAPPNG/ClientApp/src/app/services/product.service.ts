import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private _http: HttpClient;
  productList: any = [];

  constructor(private _httpSerRef: HttpClient)
  {
    this._http = _httpSerRef;
  }

  getProducts() {
   return  this._http.get('https://localhost:7222/api/products/plist');
  }

  searchProduct(pid:any) {
    return this._http.get('https://localhost:7222/api/products/plist/' + pid);
  }


  addNewProduct(newP: any) {
    console.log(newP);
    var newProduct = {
      "pId": newP.pId,
      "pName": newP.pName,
      "pCategory": newP.pCategory,
      "pPrice": newP.pPrice,
      "pIsInStock": newP.pIsInStock,
      "pManufacturer": newP.pManufacturer
    };
   
    

    return this._http.post('https://localhost:7222/api/products/plist/add',newProduct);
  }

}
