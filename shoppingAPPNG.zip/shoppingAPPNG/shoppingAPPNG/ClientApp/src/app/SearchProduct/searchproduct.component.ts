import { Component } from "@angular/core";
import { ProductService } from "../services/product.service";



@Component({
  selector: 'searchproduct',
  templateUrl: './searchproduct.component.html',
  styleUrls: ['./searchproduct.component.css']
})
export class searchproduct
{
  _produService: ProductService;
  product: any;
  productNotFoundError:any;

  constructor(_prodServiceRef: ProductService) {
    this._produService = _prodServiceRef;
  }

  searchProduct(id: any) {

    this._produService.searchProduct(id).subscribe((productData) => {
      this.product = productData;
      console.log(this.product);
      this.productNotFoundError = "";
   
    }, (err) => {
      console.log(err);
      this.product = "";
      this.productNotFoundError = err;
    })
  }
}

