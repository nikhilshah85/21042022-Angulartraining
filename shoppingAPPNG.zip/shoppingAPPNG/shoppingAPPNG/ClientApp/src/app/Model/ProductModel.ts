export class Product {

  

}
