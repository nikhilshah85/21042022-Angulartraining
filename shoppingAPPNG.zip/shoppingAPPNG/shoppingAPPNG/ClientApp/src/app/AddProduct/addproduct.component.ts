import { Component } from "@angular/core";
import { ProductService } from "../services/product.service";


@Component({
  selector: 'add-product',
  templateUrl: './addproduct.component.html',
  styleUrls: ['addproduct.component.css']
})
export class AddProduct {

  _productService: ProductService;

  constructor(_prodSerRef: ProductService) {
    this._productService = _prodSerRef;
  }

  postNewProduct(id: any, name: any, cat: any, price: any, isinstock: any, manufacturer: any) {
    if (isinstock == "on") {
      isinstock = true;
    }
    else {
      isinstock = false;
    }
      var newProduct = {
        "pId": id,
        "pName": name,
        "pCategory": cat,
        "pPrice": price,
        "pIsInStock": isinstock,
        "pManufacturer": manufacturer     
    }
    console.log(newProduct);
    this._productService.addNewProduct(newProduct).subscribe((result) => {
      console.log(result);
    })
  }
}
