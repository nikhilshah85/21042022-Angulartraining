import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {


 _prodSer: ProductService;


  constructor(_prodSerRef: ProductService) {
    this._prodSer = _prodSerRef;
  }

  getProducts() {
    this._prodSer.getProducts().subscribe((data) => {
      console.log(data);
      this._prodSer.productList = data;
    });
  }

  





}
