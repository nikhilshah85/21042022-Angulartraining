import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent {


 private _prodSer: ProductService;
  productList: any = [];

  constructor(private _prodSerRef: ProductService) {
    this._prodSer = _prodSerRef;
  }

  getProducts() {
    this.productList = this._prodSer.getProducts();
    console.log(this.productList);
  }

  





}
