import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientreport',
  templateUrl: './clientreport.component.html',
  styleUrls: ['./clientreport.component.css']
})
export class ClientreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
