import { Component, OnInit } from '@angular/core';
import { BlockService } from 'src/app/guards/block.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  _blockSer:BlockService;
  constructor(private _blockRef:BlockService) 
  {
      this._blockSer = _blockRef;
   }

   checkUserLogin(uName:any,uPwd:any)
   {
      if(uName == 'Nikhil' && uPwd == 'Password@1234')
      {
        this._blockSer.isUserLoggedIn = true;
      }
      else
      {
        alert('Invalid Credentials');
      }
   }

  //  logoutUser()
  //  {
  //    this._blockSer.isUserLoggedIn = false;
  //  }





  ngOnInit(): void {
  }

}
