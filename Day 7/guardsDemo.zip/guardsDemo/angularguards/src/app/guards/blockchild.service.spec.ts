import { TestBed } from '@angular/core/testing';

import { BlockchildService } from './blockchild.service';

describe('BlockchildService', () => {
  let service: BlockchildService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BlockchildService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
