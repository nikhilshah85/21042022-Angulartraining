import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BlockService implements CanActivate {

  constructor() { }

  isUserLoggedIn = false;

  logoutUser()
  {
    this.isUserLoggedIn = false;
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):boolean {
    
    return this.isUserLoggedIn;
    // //make a call to rest, pass username and password and get the result
    // if(10 > 20)
    // {
    //   return true;
    // }
    // else
    // {
    //   return false;
    // }
  }


}
